"""
Module provides functions to see playstation content

NOTE: None of the functions in this libary take any parameters

MAKE SURE YOUR DEVICE IS CONNECTED TO THE INTERNET
"""
